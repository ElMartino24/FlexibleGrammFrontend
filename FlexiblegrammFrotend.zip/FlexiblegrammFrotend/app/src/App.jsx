import React from "react";
import Router from "./router.jsx";

function App() {
  return (<Router/>);
};

export default App;
