function GenerateSvelteCode(diagrammString, chartType) {
    const chartObj = JSON.parse(diagrammString).nodeDataArray;

    return svelteCode;
}

export default GenerateSvelteCode;
