import React from "react";
import Header from "./header";
import ArchiveBoxes from "./archiveBoxes";


function ChartsArchive() {
  return (
    <div className="mb-[12%]">
      {/* <Header /> */}
      {/* <Cummunity />
      <DimTravler />
      <CreativitySpace /> */}
      <ArchiveBoxes/>
    </div>
  );
}

export default ChartsArchive;