import React from "react";
import ColumnChart from "../charts/columnChart/columnChart";


function Home() {
  
  return (
    <main>
          <ColumnChart />
    </main>
  );
};

export default Home;